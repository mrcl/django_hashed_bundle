from django.apps import AppConfig


class DjangoHashedBundleConfig(AppConfig):
    name = 'django_hashed_bundle'
